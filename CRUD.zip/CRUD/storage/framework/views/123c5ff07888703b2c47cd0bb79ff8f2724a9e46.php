<?php $__env->startSection('content'); ?>

    <?php if(session('successMsg')): ?>
        <div class="alert alert-dismissible alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>Well done!</strong> <?php echo e(session('successMsg')); ?>

        </div>
    <?php endif; ?>


    <table class="table table-bordered table-striped table-hover ">
        <thead>
        <tr>
            <th>ID</th>
            <th>Student Name</th>
            <th>Student Phone</th>
            <th>Email</th>

            <th class="text-center">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($student->student_id); ?></td>
                <td><?php echo e($student->student_name); ?></td>
                <td><?php echo e($student->student_phnno); ?></td>
                <td><?php echo e($student->student_email); ?></td>
                <td class="text-center"><a class="btn btn-raised btn-primary btn-sm" href="<?php echo e(route('edit',$student->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> ||
                    <a class="btn btn-raised btn-danger btn-sm" href="<?php echo e(route('delete',$student->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>


                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
<?php echo e($students->links()); ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>