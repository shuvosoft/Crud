@extends('layout.app')
@section('content')

    @if (session('successMsg'))
        <div class="alert alert-dismissible alert-success">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>Well done!</strong> {{ session('successMsg') }}
        </div>
    @endif


    <table class="table table-bordered table-striped table-hover ">
        <thead>
        <tr>
            <th>ID</th>
            <th>Student Name</th>
            <th>Student Phone</th>
            <th>Email</th>

            <th class="text-center">Action</th>
        </tr>
        </thead>
        <tbody>
        @foreach($students as $student)
            <tr>
                <td>{{$student->student_id}}</td>
                <td>{{$student->student_name}}</td>
                <td>{{$student->student_phnno}}</td>
                <td>{{$student->student_email}}</td>
                <td class="text-center"><a class="btn btn-raised btn-primary btn-sm" href="{{route('edit',$student->id)}}"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> ||
                    <a class="btn btn-raised btn-danger btn-sm" href="{{route('delete',$student->id)}}"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>


                </td>
            </tr>
            @endforeach
        </tbody>

    </table>
{{$students->links()}}
    @endsection