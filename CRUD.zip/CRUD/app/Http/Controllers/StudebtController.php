<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;

class StudebtController extends Controller
{



    public function index()
    {
//        $students= Student::all();
        $students= Student::paginate(5); //pagenation
       return view('welcome', compact('students'));
    }

    /**
     * Show the form for creating a new resource.

     */
    public function create()
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *

     */
    public function store(Request $request)
    {


        $this->validate($request,[
            'student_name' => 'required',
            'student_phnno' => 'required',
            'student_email' => 'required',

        ]);

        $student = new Student;
        $student->student_name = $request->student_name;
        $student->student_phnno = $request->student_phnno;
        $student->student_email = $request->student_email;
        $student->save();
        return redirect(route('home'))->with('successMsg', 'Student successfull Added');

    }

    /**
     * Display the specified resource.
     *
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $student= Student::find($id);
        return view('edit', compact('student'));

    }

    /**
     * Update the specified resource in storage.

     */
    public function update(Request $request, $id)
    {
     $this->validate($request,[

           'student_name' => 'required',
            'student_phnno' => 'required',
            'student_email' => 'required',
         ]);
        $student = Student::find($id);
        $student->student_name = $request->student_name;
        $student->student_phnno = $request->student_phnno;
        $student->student_email = $request->student_email;
        $student->save();
        return redirect(route('home'))->with('successMsg', 'Student successfull update');
    }





    /**
     * Remove the specified resource from storage.

     */
    public function delete($id)
    {
        Student::find($id)->delete();
        return redirect(route('home'))->with('successMsg', 'Student successfull Delete');
    }
}
